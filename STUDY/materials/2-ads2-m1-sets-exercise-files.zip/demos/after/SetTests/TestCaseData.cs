﻿
namespace SetTests
{
    public class TestCaseData<T>
    {
        public T[] Left;
        public T[] Right;
        public T[] Expected;
    }
}
